import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Dictionary 
{
	private ArrayList<String> dictionary = new ArrayList<String>();
	
	public int getVocabularySize()
	{
		//System.out.println(dictionary.size());
		return dictionary.size();
		
		
	}
	
	public boolean loadDictionaryFromFile(String filePath)
	{
		boolean a;
		File dictionary2 = new File(filePath);
		if(dictionary2.exists())
		{
			try
			{
				Scanner in = new Scanner(dictionary2);
				while (in.hasNext())
				{
					//String wordEntry = in.next();
					dictionary.add(in.next());
				}
				
				in.close();
			}
			
			catch (FileNotFoundException ex)
			{
				ex.printStackTrace();
				//System.out.println("File not found");
			}
			 
			a = true;
		}
		
		else
		{
			a = false;
		}
		System.out.println(dictionary.size());
		return a; 
	}
	
	public boolean isWord(String word)
	{
		boolean b = false; 
		
		for (int i = 0; i < dictionary.size(); i++)
		{
			if(word.equalsIgnoreCase(dictionary.get(i)))
			{
				b = true; 
				break;
			}
			
/*			else
			{
				b = false;
			}*/
		}
		
		return b;
	}
}
